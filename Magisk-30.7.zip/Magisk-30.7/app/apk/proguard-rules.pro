# Excessive obfuscation
-flattenpackagehierarchy
-allowaccessmodification
